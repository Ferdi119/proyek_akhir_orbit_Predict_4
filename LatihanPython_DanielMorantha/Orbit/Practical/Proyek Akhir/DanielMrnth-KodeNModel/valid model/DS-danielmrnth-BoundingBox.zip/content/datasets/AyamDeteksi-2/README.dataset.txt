# AyamDeteksi > 2022-11-17 7:19pm
https://universe.roboflow.com/daniel-morantha-yt377/ayamdeteksi

Provided by a Roboflow user
License: CC BY 4.0

